from classes.ninja import Ninja
from classes.pirate import Pirate
import random

michelangelo = Ninja("Michelanglo")
jack_sparrow = Pirate("Jack Sparrow")

class Game:

    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        self.active_player = p1
        self.inactive_player = p2

    def battle(self):
        while self.p1.health and self.p2.health > 0:
            self.turn()
        return self
    
    def turn(self):
        self.active_player.attack(self.inactive_player)
        self.p1.show_stats()
        self.p2.show_stats()
        self.change_turns()
        return self

    def change_turns(self):
        if self.active_player == self.p1:
            self.active_player = self.p2
            self.inactive_player = self.p1
        else:
            self.active_player = self.p1
            self.inactive_player = self.p2
        return self

game1 = Game(michelangelo, jack_sparrow)
game1.battle()
