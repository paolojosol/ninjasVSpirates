import random

class Ninja:

    def __init__( self , name ):
        self.name = name
        self.strength = 10
        self.speed = 5
        self.health = 100
    
    def show_stats( self ):
        print(f"Name: {self.name}\nStrength: {self.strength}\nSpeed: {self.speed}\nHealth: {self.health}\n")

    def attack( self , pirate ):
        random_damage = random.randint(0, self.strength)
        random_mult = random.randint(0, self.speed)
        damage = (random_damage * random_mult)
        pirate.change_health(damage * -1)
        print("*"*80)
        print(f"Michelanglo Did {damage}: Damage")
        return self

    def change_health(self, amount):
        self.health += amount
        return self